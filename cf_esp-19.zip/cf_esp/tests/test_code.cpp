// g++ -std=c++17 -I../src test_code.cpp ../src/code.cpp ../src/mem.cpp
#include "../src/code.h"
#include <cassert>
#include <cstdio>
#include <cstring>
static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %d: %s\n", __LINE__, #x); fails++; } } while (0)

struct Mem : IMem {
    uint64_t base = 0x7000000000ull; std::vector<uint8_t> d;
    Mem() : d(0x40000, 0) {}
    bool read(uint64_t a, void* o, size_t n) override { a = untag(a); if (a < base || a + n > base + d.size()) { memset(o, 0, n); return false; } memcpy(o, &d[a - base], n); return true; }
    bool write(uint64_t a, const void* i, size_t n) override { a = untag(a); if (a < base || a + n > base + d.size()) return false; memcpy(&d[a - base], i, n); return true; }
    std::vector<Region> regions() override { Region r; r.start = base; r.end = base + d.size(); r.r = r.x = true; r.path = "/data/app/x/lib/arm64/libil2cpp.so"; return {r}; }
};

int main() {
    Mem m; CodePatcher cp(m);
    // fake text: some code words, zero padding at the tail (last 0x8000 bytes)
    for (size_t i = 0; i < 0x38000; i += 4) { uint32_t w = 0xD503201Fu + (uint32_t)(i & 0xFF0000); memcpy(&m.d[i], &w, 4); }
    uint64_t fn = m.base + 0x1000;
    uint32_t first = 0xD10103FFu; memcpy(&m.d[0x1000], &first, 4);                    // sub sp, sp, #0x40

    // ret patch + restore
    uint64_t fn2 = m.base + 0x2000; uint32_t o2 = 0xA9BF7BFDu; memcpy(&m.d[0x2000], &o2, 4);
    CHECK(cp.ret_at(fn2)); uint32_t v; m.read(fn2, &v, 4); CHECK(v == a64::RET);
    cp.restore(fn2); m.read(fn2, &v, 4); CHECK(v == o2 && cp.count() == 0);

    SilentHook h(m, cp); std::string err;
    CHECK(h.install(fn, 3, err));
    m.read(fn, &v, 4); CHECK((v & 0xFC000000u) == 0x14000000u);
    uint64_t cave = h.cave();
    CHECK(cave >= m.base + 0x38000 && (cave & 15) == 0);
    uint32_t w[0x70 / 4]; m.read(cave, w, sizeof w);
    CHECK(w[0] == a64::MRS_X9_CNTVCT && w[0x38 / 4] == first && w[0x68 / 4] == first);
    // detour branches into the cave
    CHECK(fn + (uint64_t)((int64_t)((int32_t)(v << 6) >> 6) * 4) == cave);

    float dir[3] = {0.25f, -0.5f, 0.75f};
    h.feed(dir, 12345);
    float got[3]; uint64_t dl; uint32_t en;
    m.read(cave + SilentHook::VALS, got, 12); m.read(cave + SilentHook::DEADLINE, &dl, 8); m.read(cave + SilentHook::ENABLE, &en, 4);
    CHECK(got[0] == 0.25f && got[2] == 0.75f && dl == 12345 && en == 1);
    h.off(); m.read(cave + SilentHook::ENABLE, &en, 4); CHECK(en == 0);
    uint64_t reloc; m.read(cave + SilentHook::RELOC, &reloc, 8); CHECK(reloc == 0);

    // a restarted cf_core adopts the leftover detour and can still restore the original
    CodePatcher cp2(m); SilentHook h2(m, cp2);
    CHECK(h2.install(fn, 3, err) && h2.cave() == cave);
    h2.uninstall(); m.read(fn, &v, 4); CHECK(v == first);

    // adrp first instruction -> relocated through the cave
    uint64_t fn3 = m.base + 0x3000; uint32_t adrp = 0x90000108u; memcpy(&m.d[0x3000], &adrp, 4);
    SilentHook h3(m, cp); CHECK(h3.install(fn3, 4, err));
    m.read(h3.cave() + SilentHook::RELOC, &reloc, 8); CHECK(reloc == ((fn3 & ~0xFFFull) + 0x20000));
    m.read(h3.cave() + 0x38, &v, 4); CHECK((v & 0xFF000000u) == 0x58000000u);
    // bl / b first instruction is refused
    uint64_t fn4 = m.base + 0x4000; uint32_t bl = 0x94000010u; memcpy(&m.d[0x4000], &bl, 4);
    SilentHook h4(m, cp); CHECK(!h4.install(fn4, 3, err) && !err.empty());

    // quaternion: rotating +Z by look_quat(d) gives d
    Vec3 ds[] = {{0, 0, 1}, {1, 0, 0}, {0.3f, 0.4f, 0.5f}, {-0.6f, -0.3f, 0.2f}, {0, 1, 0.01f}};
    for (Vec3 d : ds) {
        float q[4]; look_quat(d, q);
        Vec3 u = norm(d), v0 = {0, 0, 1}, qv = {q[0], q[1], q[2]};
        Vec3 t = cross(qv, v0); t = {2 * t.x, 2 * t.y, 2 * t.z};
        Vec3 r = v0 + Vec3{q[3] * t.x, q[3] * t.y, q[3] * t.z} + cross(qv, t);
        CHECK(std::fabs(r.x - u.x) < 1e-4f && std::fabs(r.y - u.y) < 1e-4f && std::fabs(r.z - u.z) < 1e-4f);
    }
    {   // the cave lives in an r-x page: no instruction of it may store to memory (a store there = SIGSEGV on the first shot)
        std::vector<uint8_t> img; std::string e;
        CHECK(SilentHook::build(0x5bbd900, 0x10B527C, 0xA9BF7BFDu, 4, img, e));
        for (uint32_t o = 0; o < SilentHook::ORIGSLOT; o += 4) {
            uint32_t w; memcpy(&w, &img[o], 4);
            bool store = ((w & 0x3B000000u) == 0x39000000u && !(w & 0x00400000u)) || ((w & 0x3E000000u) == 0x28000000u && !(w & 0x00400000u)) || ((w & 0x3B200C00u) == 0x38000000u && !(w & 0x00400000u));
            CHECK(!store);
        }
    }
    printf(fails ? "%d FAILED\n" : "code ok\n", fails);
    return fails != 0;
}
